package net.sf.cglib.beans;

public class SampleSetter {

    int foo;

    public void setFoo(int foo) {
        this.foo = foo;
    }
}
