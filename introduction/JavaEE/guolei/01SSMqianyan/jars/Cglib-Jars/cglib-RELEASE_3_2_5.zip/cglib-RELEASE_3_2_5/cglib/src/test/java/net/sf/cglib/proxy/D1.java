package net.sf.cglib.proxy;

class D1 implements DI1 {
    public String herby() {
        return "D1";
    }
}
