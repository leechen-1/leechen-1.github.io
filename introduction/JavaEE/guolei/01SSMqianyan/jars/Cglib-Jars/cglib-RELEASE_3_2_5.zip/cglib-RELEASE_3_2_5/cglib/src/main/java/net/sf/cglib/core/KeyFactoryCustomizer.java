package net.sf.cglib.core;

/**
 * Marker interface for customizers of {@link KeyFactory}
 */
public interface KeyFactoryCustomizer {
}
