
function valueselect(p_frm,i,value) {
	p_frm.elements[i].value=value;
}


