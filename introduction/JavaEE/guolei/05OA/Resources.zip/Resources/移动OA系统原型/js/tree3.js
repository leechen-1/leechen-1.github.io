function tree(theName,imgName)
	{
	if(document.all[theName].style.display=="none")
		{

		document.all[theName].style.display="";
		document.all[imgName].src="../../../../images/tree_2_05.gif";

		}
	else
		{
		document.all[theName].style.display="none";
		document.all[imgName].src="../../../../images/tree_05.gif";
		}
	}
	
function head(theName,imgName)
	{
	if(document.all[theName].style.display=="none")
		{

		document.all[theName].style.display="";
		document.all[imgName].src="../../../../images/tree_2_03.gif";

		}
	else
		{
		document.all[theName].style.display="none";
		document.all[imgName].src="../../../../images/tree_03.gif";
		}
	}
	
function menu(theName,imgName)
	{
	if(document.all[theName].style.display=="none")
		{

		document.all[theName].style.display="";
		document.all[imgName].src="../../../../images/tree_2_11.gif";

		}
	else
		{
		document.all[theName].style.display="none";
		document.all[imgName].src="../../../../images/tree_11.gif";
		}
	}

function third(theName,imgName)
	{
	if(document.all[theName].style.display=="none")
		{

		document.all[theName].style.display="";
		document.all[imgName].src="../../../../images/tree_2_17.gif";

		}
	else
		{
		document.all[theName].style.display="none";
		document.all[imgName].src="../../../../images/tree_17.gif";
		}
	}
